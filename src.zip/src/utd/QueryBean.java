package utd;

public class QueryBean implements java.io.Serializable{
	private String query;
	
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}  
}